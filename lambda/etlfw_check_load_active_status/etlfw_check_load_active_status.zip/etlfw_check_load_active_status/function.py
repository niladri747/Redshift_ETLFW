import json
import os
import boto3
import psycopg2

def getCredentials():
    credential = {}
    
    secret_name = os.environ.get('secret_name')
    region_name = os.environ.get('AWS_REGION')
    
    client = boto3.client(
      service_name='secretsmanager',
      region_name=region_name
    )
    
    get_secret_value_response = client.get_secret_value(
      SecretId=secret_name
    )
    
    secret = json.loads(get_secret_value_response['SecretString'])
    
    credential['username'] = secret['username']
    credential['password'] = secret['password']
    credential['host'] = secret['host']
    credential['db'] = "postgres"
    
    return credential
    
def query_db(query, args=(), one=False):
    credential = getCredentials()
    connection = psycopg2.connect(user=credential['username'], password=credential['password'], host=credential['host'], database=credential['db'])
    cur = connection.cursor()
    cur.execute(query, args)
    results = cur.fetchone()
    #r = [dict((cur.description[i][0], value) \
    #           for i, value in enumerate(row)) for row in cur.fetchall()]
    cur.connection.close()
    #return (r[0] if r else None) if one else r
    return results
  # see above
  
  
def lambda_handler(event, context):
    load_type = event['load_type']
    load_frequency = event['load_frequency']
    schema_name = os.environ.get('pg_schema')
    print(load_type)
    print(load_frequency)
    validation_query = query_db("select case when active_flag = 'Y' then 'ok' else 'abort' end as status, case when active_flag = 'Y' then 'load active' else 'load deactivated' end as description from %s.load_tp_master where load_tp = %s and load_frequency = %s", (schema_name, load_type, load_frequency))
    results = json.dumps(validation_query)
    response = {}
    response['status'] = validation_query[0]
    response['description'] = validation_query[1]
    print (results)
    print (validation_query)
    print (response)
    return response